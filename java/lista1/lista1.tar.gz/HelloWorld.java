import java.util.Scanner;

public class HelloWorld
{
	public static void main(String[] args)
	{
		System.out.printf("%s\n", "Hello, world!");
	}
}
