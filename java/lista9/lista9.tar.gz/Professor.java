public class Professor
{
	String name = "";
	String degree = "";
	int age = 0;

	public void print()
	{
		System.out.println("\tName: " + name);
		System.out.println("\tAge: " + age);
		System.out.println("\tDegree: " + degree);
	}
}
