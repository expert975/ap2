public class Position
{
	public float x = 0, y = 0;
}
