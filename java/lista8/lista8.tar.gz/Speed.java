public class Speed
{
	public float x = 0, y = 0;
}
