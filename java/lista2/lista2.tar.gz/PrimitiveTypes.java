public class PrimitiveTypes
{
	public static void main(String[] args)
	{
		System.out.println("byte\nshort\nint\nlong\nfloat\ndouble\nboolean\nchar");
	}
}
